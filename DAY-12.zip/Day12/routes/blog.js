const express = require('express');
const router = express.Router();

//   //router level middleware
// router.use((req,res,next)=>{
//     res.send("Blog routes is initiated")
//     next()
// })

router.get('/',(req,res)=>{
    res.send("<h1>Welcome to Block Page</h1>")
}).get('/about',(req,res)=>{
    res.send("<h1>Welcome to Block About Page</h1>")
}).get('/:name',(req,res)=>{
    res.send(`<h1>The blog name is ${req.params.name}</h1>`);
}).get('/:name1/:name2',(req,res)=>{
    res.send(`<h1>The blog name is ${req.params.name1} and the topic is ${req.params.name2}</h1>`);
})

module.exports = router;