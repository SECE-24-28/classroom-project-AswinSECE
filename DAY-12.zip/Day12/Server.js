//Express.Js is a lightweight, fast and flexible web framework for node.js that we use in 
//              order to create web servers and REST API's.


const express = require('express')
const blog = require('./routes/blog');
const app = express()
const port = 3000
const fs=require('fs')


const logs = (req,res,next)=>{
    fs.appendFileSync('logs123.txt',`${req.method} Request has been sent on ${Date(Date.now())}\n`)
    next()
}
app.use(logs);

//error level middleware
app.use((error,req,res,next)=>{
  console.error(error.stock);
  res.status(500).send("Your app is broke.")
  next()
})

// //Middleware is a function that runs between request body and response body 
// //            and helps us to manipiulate or change our request body


// ///middleware 1
// const m1 = (req,res,next)=>{
//   res.send("I am logged in");
//   next();
// }
// app.use(m1)

//middleware 2
app.use((req,res,next)=>{
  // res.send('I am logged in again');

  //headers
  req.name = 'Clark'
  console.log(req.name);
  next();
})



//built-in middleware - express.static, express.json, express.urlencoded

//third party middleware -cookies.parser,cors.



//middleware  to make the said folder public so that it can be accessible to every user
app.use(express.static('public'))

app.use('/blog',blog);


//Rest API

//app.get - fetches data from the server
//app.post - sends data to the server
//app.put - update and entry in the server
//app.delete - delete an entry from the server
app.get('/', (req, res) => {
  res.send("GET request initiated for '/'")
}).post('/',(req,res)=>{
  res.send("POST request initiated for '/'")
  // res.send(__dirname)
}).put('/',(req,res)=>{
  res.send("PUT request initiated for '/'")
}).delete('/',(req,res)=>{
  res.send("DELETE request initiated for '/'")
})



app.get('/home',(req,res)=>{
     res.sendFile("/templates/home.html",{root: __dirname});
})

app.get('/contact',(req,res)=>{
     res.sendFile("/templates/contact.html",{root: __dirname});
})

app.get('/data',(req,res)=>{
     res.json({name:"Darshan S",age:18,address:"Tirupur"});
})




// app.get('/about',(req,res)=>{
//     res.send('<h1>This is an about page</h1>')
// })

// app.get('/blog',(req,res)=>{
//     res.send('<h1>Stating this is a blog page</h1>')
// })

// //This is not efficient
// app.get('/blog/html',(req,res)=>{
//     res.send('<h1>HTML blog</h1>')
// })

// app.get('/blog/css',(req,res)=>{
//     res.send('<h1>CSS blog</h1>')
// })



// //dynamic routes - efficient
// app.get('/blog/:name',(req,res)=>{
//     res.send(`<h1>This blog is about ${req.params.name}</h1>`);
// })

// //multiple dynamic routes
// app.get('/blog/:name1/:name2',(req,res)=>{
//     res.send(`<h1>This blog is about ${req.params.name1} and ${req.params.name2}</h1>`);

//     //we cannot insert sensitive information into our query as it will compromise our security 
//     console.log(req.query);
// })

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

