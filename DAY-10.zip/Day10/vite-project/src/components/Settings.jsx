import React from "react";

const Settings=()=>{
    return(
        <div className='text-center text-red-500 text-5xl'>This is a Settings</div>
    )
}

export default Settings