import React from "react";
import { useOutletContext } from "react-router-dom";

const Profile=()=>{
    const hero=useOutletContext()

    return(
      <>  
        <div className='text-center text-red-500 text-5xl'>This is a Profile</div>
        <div className='flex justify-around items-center text-4xl p-20 bg-black text-amber-600'>
            <span>Name:{hero.name}</span>
            <span>Alias:{hero.alias}</span>
            <span>Age:{hero.age}</span>
            <span>Jurisdiction:{hero.jurisdiction}</span>

        </div>
      </>
    )
}

export default Profile