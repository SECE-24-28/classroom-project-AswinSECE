import React from "react";
import {Outlet} from 'react-router-dom'

const Dashboard=()=>{
    const hero={name:'Bruce Wayne',alias:'batman',age:18,jurisdiction:'Gotham City'}
    return(
     <>
        <div className='text-center text-red-500 text-5xl'>This is a Dashboard</div>
        <Outlet context={hero}/>
    </>
    )
}

export default Dashboard