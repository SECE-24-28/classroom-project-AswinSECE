import './App.css'


function App() {

  return (
    <>
     <div className="flex justify-center items-center h-screen ">
         <div className='text-center text-red-500 text-5xl'>This is a Page</div>
     </div>
    </>
  )
}

export default App
