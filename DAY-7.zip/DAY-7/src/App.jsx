import React, { useState } from "react";
import "./App.css";

function App() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [roll, setRoll] = useState("");
  const [job, setJob] = useState("");

  // cards store submitted entries (new ones go to front)
  const [cards, setCards] = useState([
    { placeholder: true },
    { placeholder: true },
    { placeholder: true },
  ]);

  function handleSubmit(e) {
    e && e.preventDefault();
    const trimmed = name || email || roll || job;
    if (!trimmed) return; // ignore empty

    const entry = { name, email, roll, job };
    // Keep exactly 3 slots. New entry becomes first, older ones shift right,
    // and the oldest gets dropped when exceeding three.
    setCards((c) => {
      const next = [entry, c[0], c[1]].slice(0, 3);
      return next.map((x) => x || { placeholder: true });
    });
    setName("");
    setEmail("");
    setRoll("");
    setJob("");
  }

  return (
    <div className="main-box">
      <form className="top-panel" onSubmit={handleSubmit}>
        <div className="form-grid">
          <label htmlFor="name">Name</label>
          <input id="name" value={name} onChange={(e) => setName(e.target.value)} />

          <label htmlFor="email">Email</label>
          <input id="email" value={email} onChange={(e) => setEmail(e.target.value)} />

          <label htmlFor="roll">Roll No.</label>
          <input id="roll" value={roll} onChange={(e) => setRoll(e.target.value)} />

          <label htmlFor="job">Job</label>
          <input id="job" value={job} onChange={(e) => setJob(e.target.value)} />
        </div>

        <div className="submit-box">
          <button type="submit">Submit</button>
        </div>
      </form>

      <div className="divider" />

      <section className="cards">
        {cards.map((c, i) => (
          <article key={i} className={`card ${c.placeholder ? 'placeholder' : ''}`}>
            {c.placeholder ? (
              <>
                <div className="line full" />
                <div className="line med" />
                <div className="line small" />
              </>
            ) : (
              <>
                <div style={{fontSize:14}}>{c.name || '—'}</div>
                <div style={{fontSize:13, marginTop:8}}>{c.email || '—'}</div>
                <div style={{fontSize:13, marginTop:6}}>{`Roll: ${c.roll || '—'}`}</div>
                <div style={{fontSize:13, marginTop:6}}>{`Job: ${c.job || '—'}`}</div>
              </>
            )}
          </article>
        ))}
      </section>
    </div>
  );
}

export default App;
