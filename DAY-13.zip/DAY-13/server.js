import express from 'express';
import 'dotenv/config';
import connectDB from './config/db.js';
import User from './models/UserSchema.js';

const app = express();
app.use(express.static('public'));
app.use(express.json());

const PORT = process.env.PORT || 5000;

// connect to DB
connectDB();

/* ================= GET ================= */

// Get ALL users
app.get('/', async (req, res) => {
    const users = await User.find({});
    res.json(users);
});

// Get user by id
app.get('/:id', async (req, res) => {
    const user = await User.findOne({ id: req.params.id });
    if (!user) {
        return res.status(404).send('User not found');
    }
    res.json(user);
});

/* ================= POST ================= */

// Create user
app.post('/', async (req, res) => {
    const user = await User.create(req.body);
    res.status(201).json(user);
});

/* ================= PUT ================= */

// Update user by id
app.put('/:id', async (req, res) => {
    const user = await User.findOneAndUpdate(
        { id: req.params.id },
        req.body,
        { new: true, runValidators: true }
    );

    if (!user) {
        return res.status(404).send('User not found');
    }

    res.status(200).json({
        message: "User updated successfully",
        user
    });
});

/* ================= DELETE ================= */

// Delete ALL users
app.delete('/', async (req, res) => {
    await User.deleteMany({});
    res.status(200).json({ message: "All users deleted successfully" });
});

// Delete user by id
app.delete('/:id', async (req, res) => {
    const user = await User.findOneAndDelete({ id: req.params.id });
    if (!user) {
        return res.status(404).send('User not found');
    }
    res.status(200).json({ message: "User deleted successfully" });
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
