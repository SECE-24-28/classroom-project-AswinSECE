import {connect,Schema, model} from 'mongoose';

const UserSchema = new Schema({
    id: Number,
    name: String,
    age: Number,
    isAdult: Boolean,
})
const User = model('User',UserSchema);

export default User;